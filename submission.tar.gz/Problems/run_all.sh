#!/usr/bin/bash

cd Example/
make -i
make clean
cd ..

cd Merge/
make -i
make clean
cd ..

cd Quick/
make -i
make clean
cd ..

cd Bubble/
make -i
make clean
cd ..

cd Insertion/
make -i
make clean
cd ..

cd Selection/
make -i
make clean
cd ..

cd Statistics/
make -i
make clean
cd ..

cd Transpose/
make -i
make clean
cd ..

cd Histogram/
make -i
make clean
cd ..

